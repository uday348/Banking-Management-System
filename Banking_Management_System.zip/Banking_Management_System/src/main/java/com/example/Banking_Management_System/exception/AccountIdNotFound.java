package com.example.Banking_Management_System.exception;

public class AccountIdNotFound extends RuntimeException{
	
	private String message ="Account not found in the DB";

	public String getMessage() {
		return message;
	}

}
