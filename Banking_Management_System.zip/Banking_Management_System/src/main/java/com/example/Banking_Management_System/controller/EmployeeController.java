package com.example.Banking_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Banking_Management_System.dto.Employee;
import com.example.Banking_Management_System.service.EmployeeService;
import com.example.Banking_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class EmployeeController {

		@Autowired
		EmployeeService employeeService;
		
		
		
		@Operation(summary = "Save Employee", description = "API is used to save the Employee")
	 	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created"),
	 			@ApiResponse(responseCode = "404", description = "Employee not found for the given id") })
		@PostMapping("/saveEmployee")
		public ResponseEntity<ResponseStructure<Employee>> saveEmployee(@RequestBody Employee employee) {
			return employeeService.saveEmployee(employee);
		}
		
		
		
		@Operation(summary = "Fetch Employee", description = "API is used to fetch the Employee")
		@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully fetched"),
				@ApiResponse(responseCode = "404", description = "Employee not found for the given id") })
		@GetMapping("/fetchEmployeeById")
		public ResponseEntity<ResponseStructure<Employee>> fetchEmployeeById(@RequestParam int employeeId) {
			return employeeService.fetchEmployeeById(employeeId);
		}
		
		
		
		
		@Operation(summary = "Delete Employee", description = "API is used to delete the Employee")
		@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully deleted"),
				@ApiResponse(responseCode = "404", description = "Employee not found for the given id") })
		@DeleteMapping("/deleteEmployee")
		public ResponseEntity<ResponseStructure<Employee>> deleteEmployee(@RequestParam int employeeId) {
			ResponseEntity<ResponseStructure<Employee>> employee=employeeService.fetchEmployeeById(employeeId);
		    employeeService.deleteEmployee(employeeId);
		    return employee;
		}
		
		
		
		@Operation(summary = "Updated Employee", description = "API is used to update the Employee")
		@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully updated"),
				@ApiResponse(responseCode = "404", description = "Employee not found for the given id") })
		@PutMapping("/updateEmployee")
		public ResponseEntity<ResponseStructure<Employee>> updateEmployee(@RequestParam int oldEmployeeId,@RequestBody Employee newEmployee) {
			newEmployee.setEmployeeId(oldEmployeeId);
			return saveEmployee(newEmployee);
		}
		
		@GetMapping("/fetchAllEmployee")
		public List<Employee> fetchAllEmployee() {
			return employeeService.fetchAllEmployee();
		}
}
