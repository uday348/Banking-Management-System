package com.example.Banking_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Banking_Management_System.dao.ManagerDao;
import com.example.Banking_Management_System.dto.Manager;
import com.example.Banking_Management_System.exception.ManagerIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;

@Service
public class ManagerService {
	@Autowired
	ManagerDao managerDao;
	
	
	@Autowired
	ResponseStructure<Manager> responseStructure;
	
	public ResponseEntity<ResponseStructure<Manager>> saveManager(Manager manager) {
		responseStructure.setMessage("Successfully manager created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(managerDao.saveManager(manager));
		return new ResponseEntity<ResponseStructure<Manager>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Manager>> fetchManagerById(int managerId) {
		Manager manager= managerDao.fetchManagerById(managerId);
		if(manager!=null) {
		responseStructure.setMessage("Successfully manager fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(managerDao.fetchManagerById(managerId));
		return new ResponseEntity<ResponseStructure<Manager>>(responseStructure,HttpStatus.FOUND);
		} else {
			throw new ManagerIdNotFound();
		}
	}
	
	public ResponseEntity<ResponseStructure<Manager>> deleteManager(int managerId) {
		Manager manager= managerDao.fetchManagerById(managerId);
		if(manager!=null) {
		responseStructure.setMessage("Successfully manager deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(managerDao.deleteManager(managerId));
	    return new ResponseEntity<ResponseStructure<Manager>>(responseStructure,HttpStatus.OK);
	} else {
		throw new ManagerIdNotFound();
	}
	}
	
	public  ResponseEntity<ResponseStructure<Manager>> updateManager(int oldManagerId, Manager newManager) {
		Manager manager= managerDao.fetchManagerById(oldManagerId);
		if(manager!=null) {
		responseStructure.setMessage("Successfully manager deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(managerDao.updateManager(oldManagerId, newManager));
		 return new ResponseEntity<ResponseStructure<Manager>>(responseStructure,HttpStatus.OK);
	} else {
		throw new ManagerIdNotFound();
	}
	}
	
	
	
	
	public List<Manager> fetchAllManager() {
		return managerDao.fetchAllManager();
	}
	
}
