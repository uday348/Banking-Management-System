package com.example.Banking_Management_System.exception;

public class OwnerIdNotFound extends RuntimeException{
	
	private String message ="owner not found in the DB";

	public String getMessage() {
		return message;
	}
	

}
