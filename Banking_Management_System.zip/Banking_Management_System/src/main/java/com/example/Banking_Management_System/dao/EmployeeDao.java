package com.example.Banking_Management_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.Banking_Management_System.dto.Employee;
import com.example.Banking_Management_System.repo.EmployeeRepo;

@Repository
public class EmployeeDao {

	@Autowired
	EmployeeRepo employeeRepo;
	
	public Employee saveEmployee(Employee employee) {
		return employeeRepo.save(employee);
	}
	
	public Employee fetchEmployeeById(int employeeId) {
		Optional<Employee> employee= employeeRepo.findById(employeeId);
		if(employee.isEmpty()) {
			return null;
		}else {
			return employee.get();
		}
	}
	
	public Employee deleteEmployee(int employeeId) {
		Employee employee=employeeRepo.findById(employeeId).get();
	    employeeRepo.delete(employee);
	    return employee;
	}
	
	public Employee updateEmployee(int oldEmployeeId, Employee newEmployee) {
		newEmployee.setEmployeeId(oldEmployeeId);
		return saveEmployee(newEmployee);
	}
	
	public List<Employee> fetchAllEmployee() {
		return employeeRepo.findAll();
	}
}
