package com.example.Banking_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Banking_Management_System.dao.AccountDao;
import com.example.Banking_Management_System.dto.Account;
import com.example.Banking_Management_System.exception.AccountIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;

@Service
public class AccountService {
	@Autowired
	AccountDao accountDao;
	
	@Autowired
	ResponseStructure<Account> responseStructure;
	
	public ResponseEntity<ResponseStructure<Account>> saveAccount(Account account) {
		responseStructure.setMessage("Successfully Account created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(accountDao.saveAccount(account));
		return new ResponseEntity<ResponseStructure<Account>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Account>> fetchAccountById(int accountId) {
		Account account=accountDao.fetchAccountById(accountId);
		if(account!= null) {
		responseStructure.setMessage("Successfully account fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(accountDao.fetchAccountById(accountId));
		return new ResponseEntity<ResponseStructure<Account>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new AccountIdNotFound();
		}
	}
	
	public ResponseEntity<ResponseStructure<Account>> deleteAccount(int accountId) {
		Account account=accountDao.fetchAccountById(accountId);
		if(account!= null) {
		responseStructure.setMessage("Successfully account deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(accountDao.deleteAccount(accountId));
	    return new ResponseEntity<ResponseStructure<Account>>(responseStructure,HttpStatus.OK);
		}else {
			throw new AccountIdNotFound();
		}
	}
	
	public  ResponseEntity<ResponseStructure<Account>> updateAccount(int oldAccountId, Account newAccount) {
		Account account=accountDao.fetchAccountById(oldAccountId);
		if(account!= null) {
		responseStructure.setMessage("Successfully account deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(accountDao.updateAccount(oldAccountId, newAccount));
		 return new ResponseEntity<ResponseStructure<Account>>(responseStructure,HttpStatus.OK);
	}else {
		throw new AccountIdNotFound();
	}
	}
	

	
	public List<Account> fetchAllAccount() {
		return accountDao.fetchAllAccount();
	}
}
