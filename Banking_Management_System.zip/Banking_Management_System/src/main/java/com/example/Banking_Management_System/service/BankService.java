package com.example.Banking_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Banking_Management_System.dao.BankDao;
import com.example.Banking_Management_System.dto.Atm;
import com.example.Banking_Management_System.dto.Bank;
import com.example.Banking_Management_System.dto.Branch;
import com.example.Banking_Management_System.exception.BankIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;
@Service
public class BankService {
	@Autowired
	BankDao bankDao;
	
	@Autowired
	ResponseStructure<Bank> responseStructure;
	
	public ResponseEntity<ResponseStructure<Bank>> saveBank(Bank bank) {
		responseStructure.setMessage("Successfully bank created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(bankDao.saveBank(bank));
		return new ResponseEntity<ResponseStructure<Bank>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Bank>> fetchBankById(int bankId) {
		Bank bank=bankDao.fetchBankById(bankId);
		if(bank!= null) {
		responseStructure.setMessage("Successfully bank fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(bankDao.fetchBankById(bankId));
		return new ResponseEntity<ResponseStructure<Bank>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new BankIdNotFound();
		}
	}
	
	public ResponseEntity<ResponseStructure<Bank>> deleteBank(int bankId) {
		Bank bank=bankDao.fetchBankById(bankId);
		if(bank!= null) {
		responseStructure.setMessage("Successfully bank deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(bankDao.deleteBank(bankId));
	    return new ResponseEntity<ResponseStructure<Bank>>(responseStructure,HttpStatus.OK);
		}else {
			throw new BankIdNotFound();
		}
	}
	
	public  ResponseEntity<ResponseStructure<Bank>> updateBank(int oldBankId, Bank newBank) {
		Bank bank=bankDao.fetchBankById(oldBankId);
		if(bank!= null) {
		responseStructure.setMessage("Successfully bank deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(bankDao.updateBank(oldBankId, newBank));
		 return new ResponseEntity<ResponseStructure<Bank>>(responseStructure,HttpStatus.OK);
		}else {
			throw new BankIdNotFound();
		}
	}
	
	
	

	
	public List<Bank> fetchAllBank() {
		return bankDao.fetchAllBank();
	}
	
	
	// one to many -->Branch
	public Bank addExistingBranchToExistingBank(int branchId,int bankId) {
		return bankDao.addExistingBranchToExistingBank(branchId, bankId);
	}
	
	public Bank addNewBranchToExistingBank(int bankId, Branch newBranch) {
		return bankDao.addNewBranchToExistingBank(bankId, newBranch);
	}
	
	
	// one to many -->Atm
	public Bank addExistingAtmToExistingBank(int atmId,int bankId) {
		return bankDao.addExistingAtmToExistingBank(atmId, bankId);
	}
	
	public Bank addNewAtmToExistingBank(int bankId, Atm newAtm) {
		return bankDao.addNewAtmToExistingBank(bankId, newAtm);
	}
	
	
}
