package com.example.Banking_Management_System.exception;

public class AtmIdNotFound extends RuntimeException{
	
	private String message ="Atm not found in the DB";

	public String getMessage() {
		return message;
	}

}
