package com.example.Banking_Management_System.exception;

public class CardIdNotFound extends RuntimeException{
	
	private String message ="Card not found in the DB";

	public String getMessage() {
		return message;
	}


}
