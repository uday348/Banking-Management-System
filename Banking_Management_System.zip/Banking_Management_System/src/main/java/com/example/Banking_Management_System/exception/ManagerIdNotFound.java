package com.example.Banking_Management_System.exception;

public class ManagerIdNotFound extends RuntimeException{
	
	private String message ="Manager not found in the DB";

	public String getMessage() {
		return message;
	}


}
