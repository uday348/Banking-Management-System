package com.example.Banking_Management_System.dao;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.example.Banking_Management_System.dto.Account;
import com.example.Banking_Management_System.repo.AccountRepo;

@Repository
public class AccountDao {
	@Autowired
	AccountRepo accountRepo;
	
	public Account saveAccount(Account account) {
		return accountRepo.save(account);
	}
	
	
	public Account fetchAccountById(int accountId) {
		Optional<Account> account= accountRepo.findById(accountId);
		if(account.isEmpty()) {
			return null;
		}else {
			return account.get();
		}
	}
	
	public Account deleteAccount(int accountId) {
		Account account=accountRepo.findById(accountId).get();
	    accountRepo.delete(account);
	    return account;
	}
	
	public Account updateAccount(int oldAccountId, Account newAccount) {
		newAccount.setAccountId(oldAccountId);
		return saveAccount(newAccount);
	}
	
	public List<Account> fetchAllAccount() {
		return accountRepo.findAll();
	}
}
