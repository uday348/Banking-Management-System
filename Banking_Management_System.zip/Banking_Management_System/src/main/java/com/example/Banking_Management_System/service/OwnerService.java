package com.example.Banking_Management_System.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.example.Banking_Management_System.dao.OwnerDao;
import com.example.Banking_Management_System.dto.Owner;
import com.example.Banking_Management_System.exception.OwnerIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;

@Service
public class OwnerService {
	@Autowired
	OwnerDao ownerDao;
	
	@Autowired
	ResponseStructure<Owner> responseStructure;
	
	public ResponseEntity<ResponseStructure<Owner>> saveOwner(Owner owner) {
		responseStructure.setMessage("Successfully owner created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(ownerDao.saveOwner(owner));
		return new ResponseEntity<ResponseStructure<Owner>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Owner>> fetchOwnerById(int ownerId) {
		Owner owner=ownerDao.fetchOwnerById(ownerId);
		if(owner!= null) {
		responseStructure.setMessage("Successfully owner fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(ownerDao.fetchOwnerById(ownerId));
		return new ResponseEntity<ResponseStructure<Owner>>(responseStructure,HttpStatus.FOUND);
	}else {
		throw new OwnerIdNotFound();
	}
	}
	
	public ResponseEntity<ResponseStructure<Owner>> deleteOwner(int ownerId) {
		Owner owner=ownerDao.fetchOwnerById(ownerId);
		if(owner!= null) {
		responseStructure.setMessage("Successfully owner deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(ownerDao.deleteOwner(ownerId));
	    return new ResponseEntity<ResponseStructure<Owner>>(responseStructure,HttpStatus.OK);
		}else {
			throw new OwnerIdNotFound();
		}
	}
	
	public  ResponseEntity<ResponseStructure<Owner>> updateOwner(int oldOwnerId, Owner newOwner) {
		Owner owner=ownerDao.fetchOwnerById(oldOwnerId);
		if(owner!= null) {
		responseStructure.setMessage("Successfully owner deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(ownerDao.updateOwner(oldOwnerId, newOwner));
		 return new ResponseEntity<ResponseStructure<Owner>>(responseStructure,HttpStatus.OK);
		}else {
			throw new OwnerIdNotFound();
		}
	}
	
	
	
	public List<Owner> fetchAllOwner() {
		return ownerDao.fetchAllOwner();
	}
	
	// One to One
		public Owner addExistingBankToExistingOwner(int ownerId,int bankId) {
			return ownerDao.addExistingBankToExistingOwner(ownerId,bankId);
		}
}
