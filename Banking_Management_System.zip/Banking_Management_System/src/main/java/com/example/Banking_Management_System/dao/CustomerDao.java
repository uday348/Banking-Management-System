package com.example.Banking_Management_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.Banking_Management_System.dto.Account;
import com.example.Banking_Management_System.dto.Card;
import com.example.Banking_Management_System.dto.Customer;
import com.example.Banking_Management_System.dto.Loan;
import com.example.Banking_Management_System.repo.CustomerRepo;

@Repository
public class CustomerDao {

	@Autowired
	CustomerRepo customerRepo;

	@Autowired
	LoanDao loanDao;
	@Autowired
	AccountDao accountDao;
	@Autowired
	CardDao cardDao;

	public Customer saveCustomer(Customer customer) {
		return customerRepo.save(customer);
	}

	public Customer fetchCustomerById(int customerId) {
		Optional<Customer> customer= customerRepo.findById(customerId);
		if(customer.isEmpty()) {
			return null;
		}else {
			return customer.get();
		}
	}

	public Customer deleteCustomer(int customerId) {
		Customer customer = customerRepo.findById(customerId).get();
		customerRepo.delete(customer);
		return customer;
	}

	public Customer updateCustomer(int oldCustomerId, Customer newCustomer) {
		newCustomer.setCustomerId(oldCustomerId);
		return saveCustomer(newCustomer);
	}

	public List<Customer> fetchAllCustomer() {
		return customerRepo.findAll();
	}
	
	
	
	
	// one to many-- account

		public Customer addExistingAccountToExistingCustomer(int customerId, int accountId) {
			Account account = accountDao.fetchAccountById(accountId);
			Customer customer = fetchCustomerById(customerId);
			List<Account> list = customer.getAccounts();
			list.add(account);
			customer.setAccounts(list);
			return saveCustomer(customer);
		}

		public Customer addNewAccountToExistingCustomer(int customerId, Account newAccount) {
			Customer customer = fetchCustomerById(customerId);
			List<Account> list = customer.getAccounts();
			list.add(newAccount);
			customer.setAccounts(list);
			return saveCustomer(customer);
		} 

	// one to many-- loan

	public Customer addExistingLoanToExistingCustomer(int customerId, int loanId) {
		Loan loan = loanDao.fetchLoanById(loanId);
		Customer customer = fetchCustomerById(customerId);
		List<Loan> list = customer.getLoans();
		list.add(loan);
		customer.setLoans(list);
		return saveCustomer(customer);
	}

	public Customer addNewLoanToExistingCustomer(int customerId, Loan newLoan) {
		Customer customer = fetchCustomerById(customerId);
		List<Loan> list = customer.getLoans();
		list.add(newLoan);
		customer.setLoans(list);
		return saveCustomer(customer);
	}

	// one to many-- card

	public Customer addExistingCardToExistingCustomer(int customerId, int cardId) {
		Card card = cardDao.fetchCardById(cardId);
		Customer customer = fetchCustomerById(customerId);
		List<Card> list = customer.getCards();
		list.add(card);
		customer.setCards(list);
		return saveCustomer(customer);
	}

	public Customer addNewCardToExistingCustomer(int customerId, Card newCard) {
		Customer customer = fetchCustomerById(customerId);
		List<Card> list = customer.getCards();
		list.add(newCard);
		customer.setCards(list);
		return saveCustomer(customer);
	}
	

}