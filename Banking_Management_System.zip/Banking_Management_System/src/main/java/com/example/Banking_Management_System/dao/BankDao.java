package com.example.Banking_Management_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.Banking_Management_System.dto.Atm;
import com.example.Banking_Management_System.dto.Bank;
import com.example.Banking_Management_System.dto.Branch;
import com.example.Banking_Management_System.repo.BankRepo;

@Repository
public class BankDao {
	@Autowired
	BankRepo bankRepo;
	
	@Autowired
	BranchDao branchDao;
	
	@Autowired
	AtmDao atmDao;
	
	public Bank saveBank(Bank bank) {
		return bankRepo.save(bank);
	}
	
	public Bank fetchBankById(int bankId) {
		Optional<Bank> bank= bankRepo.findById(bankId);
		if(bank.isEmpty()) {
			return null;
		}else {
			return bank.get();
		}
	}
	
	public Bank deleteBank(int bankId) {
		Bank bank=bankRepo.findById(bankId).get();
	    bankRepo.delete(bank);
	    return bank;
	}
	
	public Bank updateBank(int oldbankId, Bank newbank) {
		newbank.setBankId(oldbankId);
		return saveBank(newbank);
	}
	
	public List<Bank> fetchAllBank() {
		return bankRepo.findAll();
	}
	
	// one to many
	public Bank addExistingBranchToExistingBank(int branchId,int bankId) {
		Branch branch=branchDao.fetchBranchById(branchId);
		Bank bank=fetchBankById(bankId);
		List<Branch> list = bank.getBranches();
		list.add(branch);
		bank.setBranches(list);
		return saveBank(bank);
	}
	
	// one to many
	public Bank addNewBranchToExistingBank(int bankId, Branch newBranch) {
		Bank bank=fetchBankById(bankId);
		List<Branch> list=bank.getBranches();
		list.add(newBranch);
		bank.setBranches(list);
		return saveBank(bank);	
	}
	
	// one to many
		public Bank addExistingAtmToExistingBank(int atmId,int bankId) {
			Atm atm=atmDao.fetchAtmById(atmId);
			Bank bank=fetchBankById(bankId);
			List<Atm> list = bank.getAtms();
			list.add(atm);
			bank.setAtms(list);
			return saveBank(bank);
		}
		
		// one to many
		public Bank addNewAtmToExistingBank(int bankId, Atm newAtm) {
			Bank bank=fetchBankById(bankId);
			List<Atm> list=bank.getAtms();
			list.add(newAtm);
			bank.setAtms(list);
			return saveBank(bank);	
		}
	
}
