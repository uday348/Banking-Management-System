package com.example.Banking_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Banking_Management_System.dao.AtmDao;
import com.example.Banking_Management_System.dto.Atm;
import com.example.Banking_Management_System.exception.AtmIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;

@Service
public class AtmService {

	@Autowired
	AtmDao atmDao;
	
	@Autowired
	ResponseStructure<Atm> responseStructure;
	
	public ResponseEntity<ResponseStructure<Atm>> saveAtm(Atm atm) {
		responseStructure.setMessage("Successfully atm created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(atmDao.saveAtm(atm));
		return new ResponseEntity<ResponseStructure<Atm>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Atm>> fetchAtmById(int atmId) {
		Atm atm=atmDao.fetchAtmById(atmId);
		if(atm!= null) {
		responseStructure.setMessage("Successfully atm fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(atmDao.fetchAtmById(atmId));
		return new ResponseEntity<ResponseStructure<Atm>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new AtmIdNotFound();
		}
	}
	
	public ResponseEntity<ResponseStructure<Atm>> deleteAtm(int atmId) {
		Atm atm=atmDao.fetchAtmById(atmId);
		if(atm!= null) {
		responseStructure.setMessage("Successfully atm deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(atmDao.deleteAtm(atmId));
	    return new ResponseEntity<ResponseStructure<Atm>>(responseStructure,HttpStatus.OK);
		}else {
			throw new AtmIdNotFound();
		}
	}
	
		
	public  ResponseEntity<ResponseStructure<Atm>> updateAtm(int oldAtmId, Atm newAtm) {
		Atm atm=atmDao.fetchAtmById(oldAtmId);
		if(atm!= null) {
		responseStructure.setMessage("Successfully atm deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(atmDao.updateAtm(oldAtmId, newAtm));
		 return new ResponseEntity<ResponseStructure<Atm>>(responseStructure,HttpStatus.OK);
	}else {
		throw new AtmIdNotFound();
	}
	}
	
	public List<Atm> fetchAllAtm() {
		return atmDao.fetchAllAtm();
	}
}
