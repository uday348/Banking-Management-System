 package com.example.Banking_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Banking_Management_System.dao.EmployeeDao;
import com.example.Banking_Management_System.dto.Employee;
import com.example.Banking_Management_System.exception.EmployeeIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;

@Service
public class EmployeeService {
	@Autowired
      EmployeeDao employeeDao;
	
	@Autowired
	ResponseStructure<Employee> responseStructure;
	
	public ResponseEntity<ResponseStructure<Employee>> saveEmployee(Employee employee) {
		responseStructure.setMessage("Successfully employee created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(employeeDao.saveEmployee(employee));
		return new ResponseEntity<ResponseStructure<Employee>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Employee>> fetchEmployeeById(int employeeId) {
		Employee employee= employeeDao.fetchEmployeeById(employeeId);
		if(employee!=null) {
		responseStructure.setMessage("Successfully employee fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(employeeDao.fetchEmployeeById(employeeId));
		return new ResponseEntity<ResponseStructure<Employee>>(responseStructure,HttpStatus.FOUND);
		} else {
			throw new EmployeeIdNotFound();
		}
	}
	
	public ResponseEntity<ResponseStructure<Employee>> deleteEmployee(int employeeId) {
		Employee employee= employeeDao.fetchEmployeeById(employeeId);
		if(employee!=null) {
		responseStructure.setMessage("Successfully employee deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(employeeDao.deleteEmployee(employeeId));
	    return new ResponseEntity<ResponseStructure<Employee>>(responseStructure,HttpStatus.OK);
	} else {
		throw new EmployeeIdNotFound();
	}
	}
	
	public  ResponseEntity<ResponseStructure<Employee>> updateEmployee(int oldEmployeeId, Employee newEmployee) {
		Employee employee= employeeDao.fetchEmployeeById(oldEmployeeId);
		if(employee!=null) {
		responseStructure.setMessage("Successfully employee deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(employeeDao.updateEmployee(oldEmployeeId, newEmployee));
		 return new ResponseEntity<ResponseStructure<Employee>>(responseStructure,HttpStatus.OK);
	} else {
		throw new EmployeeIdNotFound();
	}
	}
	
	public List<Employee> fetchAllEmployee() {
		return employeeDao.fetchAllEmployee();
	}
}
