package com.example.Banking_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Banking_Management_System.dto.Branch;
import com.example.Banking_Management_System.dto.Customer;
import com.example.Banking_Management_System.dto.Employee;
import com.example.Banking_Management_System.service.BranchService;
import com.example.Banking_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class BranchController {
	@Autowired
	BranchService branchService;
	
	
	
	@Operation(summary = "Save Branch", description = "API is used to save the Branch")
 	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created"),
 			@ApiResponse(responseCode = "404", description = "Branch not found for the given id") })
	@PostMapping("/saveBranch")
	public ResponseEntity<ResponseStructure<Branch>> saveBranch(@RequestBody Branch branch) {
		return branchService.saveBranch(branch);
	}
	
	

	@Operation(summary = "Fetch Branch", description = "API is used to fetch the Branch")
 	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully fetched"),
 			@ApiResponse(responseCode = "404", description = "Branch not found for the given id") })
	@GetMapping("/fetchBranchById")
	public ResponseEntity<ResponseStructure<Branch>> fetchBranchById(@RequestParam int branchId) {
		return branchService.fetchBranchById(branchId);
	}
	
	
	
	@Operation(summary = "Delete Branch", description = "API is used to delete the Branch")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully deleted"),
			@ApiResponse(responseCode = "404", description = "Branch not found for the given id") })
	@DeleteMapping("/deleteBranch")
	public ResponseEntity<ResponseStructure<Branch>> deleteBranch(@RequestParam int branchId) {
		ResponseEntity<ResponseStructure<Branch>> branch=branchService.fetchBranchById(branchId);
		branchService.deleteBranch(branchId);
		return branch;
	}
	
	
	
	
	
	
	@Operation(summary = "Updated Branch", description = "API is used to update the Branch")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully updated"),
			@ApiResponse(responseCode = "404", description = "Branch not found for the given id") })
	@PutMapping("/updateBranch")
	public ResponseEntity<ResponseStructure<Branch>> updateBranch(@RequestParam int oldBranchId,@RequestBody Branch newBranch) {
		newBranch.setBranchId(oldBranchId);
		return saveBranch(newBranch);
	}
	
	@GetMapping("/fetchAllBranch")
	public List<Branch> fetchAllBranch() {
		return branchService.fetchAllBranch();
	}
	
	// One to One
	@PutMapping("/addExistingManagerToExistingBranch")
		public Branch addExistingManagerToExistingBranch(@RequestParam int branchId,@RequestParam int managerId) {
			return branchService.addExistingManagerToExistingBranch( branchId,managerId);
		}
	
	// One to One
	@PutMapping("/addExistingAddressToExistingBranch")
			public Branch addExistingAddressToExistingBranch(@RequestParam int branchId,@RequestParam int addressId) {
				return branchService.addExistingManagerToExistingBranch( branchId,addressId);
			}
	
	
	
	// one to many-- employee
	@PutMapping("/addExistingEmployeeToExistingbranch")
	 public Branch addExistingEmployeeToExistingbranch(@RequestParam int branchId,@RequestParam int employeeId) {
	  return branchService.addExistingEmployeeToExistingbranch(branchId, employeeId);
	 }
			
	@PutMapping("/addnewEmployeeToExistingBranch")
     public Branch addnewEmployeeToExistingBranch(@RequestParam int branchId,@RequestBody Employee newEmployee) {
		return branchService.addnewEmployeeToExistingBranch(branchId, newEmployee);
	  }
			
			
			
		// one to many-- Customer
	    @PutMapping("/addExistingCustomerToExistingBranch")
		public Branch addExistingCustomerToExistingBranch(@RequestParam int branchId,@RequestParam int customerId) {
			return branchService.addExistingCustomerToExistingBranch(branchId, customerId);	
		}
		@PutMapping("/addNewCustomerToExistingBranch")
		public Branch addNewCustomerToExistingBranch(@RequestParam int branchId,@RequestBody Customer newCustomer) {
			return branchService.addNewCustomerToExistingBranch(branchId, newCustomer);
		}
}
