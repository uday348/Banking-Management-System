package com.example.Banking_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Banking_Management_System.dto.Account;
import com.example.Banking_Management_System.dto.Card;
import com.example.Banking_Management_System.dto.Customer;
import com.example.Banking_Management_System.dto.Loan;
import com.example.Banking_Management_System.service.CustomerService;
import com.example.Banking_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;

	
	
	@Operation(summary = "Save Customer", description = "API is used to save the Customer")
 	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created"),
 			@ApiResponse(responseCode = "404", description = "Customer not found for the given id") })
	@PostMapping("/saveCustomer")
	public ResponseEntity<ResponseStructure<Customer>> saveCustomer(@RequestBody Customer customer) {
		return customerService.saveCustomer(customer);
	}

	
	
	@Operation(summary = "Fetch Customer", description = "API is used to fetch the Customer")
 	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully fetched"),
 			@ApiResponse(responseCode = "404", description = "Customer not found for the given id") })
	@GetMapping("/fetchCustomerById")
	public ResponseEntity<ResponseStructure<Customer>> fetchCustomerById(@RequestParam int customerId) {
		return customerService.fetchCustomerById(customerId);
	}

	
	@Operation(summary = "Delete Customer", description = "API is used to delete the Customer")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully deleted"),
			@ApiResponse(responseCode = "404", description = "Customer not found for the given id") })
	@DeleteMapping("/deleteCustomer")
	public ResponseEntity<ResponseStructure<Customer>> deleteCustomer(@RequestParam int customerId) {
		ResponseEntity<ResponseStructure<Customer>> customer = customerService.fetchCustomerById(customerId);
		customerService.deleteCustomer(customerId);
		return customer;
	}

	
	
	@Operation(summary = "Updated Customer", description = "API is used to update the Customer")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully updated"),
			@ApiResponse(responseCode = "404", description = "Customer not found for the given id") })
	@PutMapping("/updateCustomer")
	public ResponseEntity<ResponseStructure<Customer>> updateCustomer(@RequestParam int oldCustomerId, @RequestBody Customer newCustomer) {
		newCustomer.setCustomerId(oldCustomerId);
		return saveCustomer(newCustomer);
	}

	@GetMapping("/fetchAllCustomer")
	public List<Customer> fetchAllCustomer() {
		return customerService.fetchAllCustomer();
	}

	
	
	
	
	
	
	
	// one to many-- account
	@PutMapping("/addExistingAccountToExistingCustomer")
	public Customer addExistingAccountToExistingCustomer(@RequestParam int customerId,@RequestParam int accountId) {
		return customerService.addExistingAccountToExistingCustomer(customerId, accountId);
	}
	@PutMapping("/addNewAccountToExistingCustomer")
	public Customer addNewAccountToExistingCustomer(@RequestParam int customerId,@RequestBody Account newAccount) {
		return customerService.addNewAccountToExistingCustomer(customerId, newAccount);
	}

	
	
	// one to many-- Loan
	@PutMapping("/addExistingLoanToExistingCustomer")
	public Customer addExistingLoanToExistingCustomer(@RequestParam int customerId,@RequestParam int loanId) {
		return customerService.addExistingLoanToExistingCustomer(customerId, loanId);
	}
	@PutMapping("/addNewLoanToExistingCustomer")
	public Customer addNewLoanToExistingCustomer(@RequestParam int customerId,@RequestBody Loan newLoan) {
		return customerService.addNewLoanToExistingCustomer(customerId, newLoan);
	}

	
	
	// one to many-- Card
	@PutMapping("/addExistingCardToExistingCustomer")
	public Customer addExistingCardToExistingCustomer(@RequestParam int customerId,@RequestParam int carId) {
		return customerService.addExistingCardToExistingCustomer(customerId, carId);
	}
	@PutMapping("/addNewCardToExistingCustomer")
	public Customer addNewCardToExistingCustomer(@RequestParam int customerId,@RequestBody Card newCard) {
		return customerService.addNewCardToExistingCustomer(customerId, newCard);
	}
	
	
	
}
