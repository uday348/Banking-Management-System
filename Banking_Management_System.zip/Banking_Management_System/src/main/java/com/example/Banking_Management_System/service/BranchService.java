package com.example.Banking_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Banking_Management_System.dao.BranchDao;
import com.example.Banking_Management_System.dto.Branch;
import com.example.Banking_Management_System.dto.Customer;
import com.example.Banking_Management_System.dto.Employee;
import com.example.Banking_Management_System.exception.BranchIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;

@Service
public class BranchService {

	@Autowired
	BranchDao branchDao;


	@Autowired
	ResponseStructure<Branch> responseStructure;
	
	public ResponseEntity<ResponseStructure<Branch>> saveBranch(Branch branch) {
		responseStructure.setMessage("Successfully branch created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(branchDao.saveBranch(branch));
		return new ResponseEntity<ResponseStructure<Branch>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Branch>> fetchBranchById(int branchId) {
		Branch branch=branchDao.fetchBranchById(branchId);
		if(branch!=null) {
		responseStructure.setMessage("Successfully branch fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(branchDao.fetchBranchById(branchId));
		return new ResponseEntity<ResponseStructure<Branch>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new BranchIdNotFound();
		}
	}
	
	public ResponseEntity<ResponseStructure<Branch>> deleteBranch(int branchId) {
		Branch branch=branchDao.fetchBranchById(branchId);
		if(branch!=null) {
		responseStructure.setMessage("Successfully branch deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(branchDao.deleteBranch(branchId));
	    return new ResponseEntity<ResponseStructure<Branch>>(responseStructure,HttpStatus.OK);
		}else {
			throw new BranchIdNotFound();
		}
	}
	
	public  ResponseEntity<ResponseStructure<Branch>> updateBranch(int oldBranchId, Branch newBranch) {
		Branch branch=branchDao.fetchBranchById(oldBranchId);
		if(branch!=null) {
		responseStructure.setMessage("Successfully branch deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(branchDao.updateBranch(oldBranchId, newBranch));
		 return new ResponseEntity<ResponseStructure<Branch>>(responseStructure,HttpStatus.OK);
		}else {
			throw new BranchIdNotFound();
		}
	}
	
	
	
	
	
	
	

	public List<Branch> fetchAllBranch() {
		return branchDao.fetchAllBranch();
	}

	// One to One
	public Branch addExistingManagerToExistingBranch(int branchId,int managerId) {
		return branchDao.addExistingManagerToExistingBranch( branchId,managerId);
	}
	
	// One to One
		public Branch addExistingAddressToExistingBranch(int branchId,int addressId) {
			return branchDao.addExistingManagerToExistingBranch( branchId,addressId);
		}
		
		
		
		// one to many-- employee
		public Branch addExistingEmployeeToExistingbranch(int branchId, int employeeId) {
			return branchDao.addExistingEmployeeToExistingbranch(branchId, employeeId);
		}
		
		public Branch addnewEmployeeToExistingBranch(int branchId, Employee newEmployee) {
			return branchDao.addnewEmployeeToExistingBranch(branchId, newEmployee);
		}
		
		
		
	// one to many-- Customer
	public Branch addExistingCustomerToExistingBranch(int branchId, int customerId) {
		return branchDao.addExistingCustomerToExistingBranch(branchId, customerId);	
	}
	
	public Branch addNewCustomerToExistingBranch(int branchId, Customer newCustomer) {
		return branchDao.addNewCustomerToExistingBranch(branchId, newCustomer);
	}
}
