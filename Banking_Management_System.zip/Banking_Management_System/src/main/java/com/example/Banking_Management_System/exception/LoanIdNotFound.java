package com.example.Banking_Management_System.exception;

public class LoanIdNotFound extends RuntimeException{
	
	private String message ="Loan not found in the DB";

	public String getMessage() {
		return message;
	}


}
