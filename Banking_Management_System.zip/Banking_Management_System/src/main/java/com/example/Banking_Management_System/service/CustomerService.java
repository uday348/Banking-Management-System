package com.example.Banking_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Banking_Management_System.dao.CustomerDao;
import com.example.Banking_Management_System.dto.Account;
import com.example.Banking_Management_System.dto.Card;
import com.example.Banking_Management_System.dto.Customer;
import com.example.Banking_Management_System.dto.Loan;
import com.example.Banking_Management_System.exception.CustomerIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;

@Service
public class CustomerService {
	@Autowired
	CustomerDao customerDao;

	
	@Autowired
	ResponseStructure<Customer> responseStructure;
	
	public ResponseEntity<ResponseStructure<Customer>> saveCustomer(Customer customer) {
		responseStructure.setMessage("Successfully customer created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(customerDao.saveCustomer(customer));
		return new ResponseEntity<ResponseStructure<Customer>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Customer>> fetchCustomerById(int customerId) {
		Customer customer=customerDao.fetchCustomerById(customerId);
		if(customer!=null) {
		responseStructure.setMessage("Successfully customer fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(customerDao.fetchCustomerById(customerId));
		return new ResponseEntity<ResponseStructure<Customer>>(responseStructure,HttpStatus.FOUND);
		} else {
			throw new CustomerIdNotFound();
		}
	}
	
	public ResponseEntity<ResponseStructure<Customer>> deleteCustomer(int customerId) {
		Customer customer=customerDao.fetchCustomerById(customerId);
		if(customer!=null) {
		responseStructure.setMessage("Successfully customer deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(customerDao.deleteCustomer(customerId));
	    return new ResponseEntity<ResponseStructure<Customer>>(responseStructure,HttpStatus.OK);
		} else {
			throw new CustomerIdNotFound();
		}
	}
	
	public  ResponseEntity<ResponseStructure<Customer>> updateCustomer(int oldCustomerId, Customer newCustomer) {
		Customer customer=customerDao.fetchCustomerById(oldCustomerId);
		if(customer!=null) {
		responseStructure.setMessage("Successfully customer deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(customerDao.updateCustomer(oldCustomerId, newCustomer));
		 return new ResponseEntity<ResponseStructure<Customer>>(responseStructure,HttpStatus.OK);
		} else {
			throw new CustomerIdNotFound();
		}
	}
	
	
	

	public List<Customer> fetchAllCustomer() {
		return customerDao.fetchAllCustomer();
	}
	
	
	
	// one to many-- account
	public Customer addExistingAccountToExistingCustomer(int customerId, int accountId) {
	return customerDao.addExistingAccountToExistingCustomer(customerId, accountId);
	}
	public Customer addNewAccountToExistingCustomer(int customerId, Account newAccount) {
		return customerDao.addNewAccountToExistingCustomer(customerId, newAccount);
	}
	
	
	// one to many-- Loan
		public Customer addExistingLoanToExistingCustomer(int customerId, int loanId) {
		return customerDao.addExistingLoanToExistingCustomer(customerId, loanId);
		}
		public Customer addNewLoanToExistingCustomer(int customerId, Loan newLoan) {
			return customerDao.addNewLoanToExistingCustomer(customerId, newLoan);
		}
		
		
		// one to many-- Card
		public Customer addExistingCardToExistingCustomer(int customerId, int carId) {
		return customerDao.addExistingCardToExistingCustomer(customerId, carId);
		}
		public Customer addNewCardToExistingCustomer(int customerId, Card newCard) {
			return customerDao.addNewCardToExistingCustomer(customerId, newCard);
		}
	
	
}
