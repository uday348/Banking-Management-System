package com.example.Banking_Management_System.exception;

public class EmployeeIdNotFound extends RuntimeException{
	
	private String message ="Employee not found in the DB";

	public String getMessage() {
		return message;
	}


}
