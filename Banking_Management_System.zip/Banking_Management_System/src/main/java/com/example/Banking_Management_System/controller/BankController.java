package com.example.Banking_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Banking_Management_System.dto.Atm;
import com.example.Banking_Management_System.dto.Bank;
import com.example.Banking_Management_System.dto.Branch;
import com.example.Banking_Management_System.service.BankService;
import com.example.Banking_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class BankController {
	@Autowired
	BankService bankService;
	
	
	
	@Operation(summary = "Save Bank", description = "API is used to save the Bank")
 	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created"),
 			@ApiResponse(responseCode = "404", description = "Bank not found for the given id") })
	@PostMapping("/saveBank")
	public ResponseEntity<ResponseStructure<Bank>> saveBank(@RequestBody Bank bank) {
		return bankService.saveBank(bank);
	}
	
	
	
	
	
	@Operation(summary = "Fetch Bank", description = "API is used to fetch the Bank")
 	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully fetched"),
 			@ApiResponse(responseCode = "404", description = "Bank not found for the given id") })
	@GetMapping("/fetchBankById")
	public ResponseEntity<ResponseStructure<Bank>> fetchBankById(@RequestParam int bankId) {
		return bankService.fetchBankById(bankId);
	}
	
	
	
	
	@Operation(summary = "Delete Bank", description = "API is used to delete the Bank")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully deleted"),
			@ApiResponse(responseCode = "404", description = "Bank not found for the given id") })
	@DeleteMapping("/deleteBank")
	public ResponseEntity<ResponseStructure<Bank>> deleteBank(@RequestParam int bankId) {
		ResponseEntity<ResponseStructure<Bank>> bank=bankService.fetchBankById(bankId);
	    bankService.deleteBank(bankId);
	    return bank;
	}
	
	
	
	
	@Operation(summary = "Updated Bank", description = "API is used to update the Bank")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully updated"),
			@ApiResponse(responseCode = "404", description = "Bank not found for the given id") })
	@PutMapping("/updateBank")
	public ResponseEntity<ResponseStructure<Bank>> updateBank(@RequestParam int oldbankId,@RequestBody Bank newbank) {
		newbank.setBankId(oldbankId);
		return saveBank(newbank);
	}
	
	@GetMapping("/fetchAllBank")
	public List<Bank> fetchAllBank() {
		return bankService.fetchAllBank();
	}
	
	
	@PutMapping("/addExistingBranchToExistingBank")
	public Bank addExistingBranchToExistingBank(@RequestParam int branchId,@RequestParam int bankId) {
		return bankService.addExistingBranchToExistingBank(branchId, bankId);
	}
	
	@PutMapping("/addNewBranchToExistingBank")
	public Bank addNewBranchToExistingBank(@RequestParam int bankId,@RequestBody Branch newBranch) {
		return bankService.addNewBranchToExistingBank(bankId, newBranch);
	}
	
	@PutMapping("/addExistingAtmToExistingBank")
	public Bank addExistingAtmToExistingBank(@RequestParam int atmId,@RequestParam int bankId) {
		return bankService.addExistingAtmToExistingBank(atmId, bankId);
	}
	
	@PutMapping("/addNewAtmToExistingBank")
	public Bank addNewAtmToExistingBank(@RequestParam int bankId,@RequestBody Atm newAtm) {
		return bankService.addNewAtmToExistingBank(bankId, newAtm);
	}
	
	
}
