package com.example.Banking_Management_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.example.Banking_Management_System.dto.Address;
import com.example.Banking_Management_System.repo.AddressRepo;

@Repository
public class AddressDao {

	@Autowired
	AddressRepo addressRepo;
	
	public Address saveAddress(Address address) {
		return addressRepo.save(address);
	}
	
	public Address fetchAddressById(int addressId) {
		Optional<Address> address= addressRepo.findById(addressId);
		if(address.isEmpty()) {
			return null;
		}else {
			return address.get();
		}
	}
	
	public Address deleteAddress(int addressId) {
		Address address=addressRepo.findById(addressId).get();
	    addressRepo.delete(address);
	    return address;
	}
	
	public Address updateAddress(int oldAddressId, Address newAddress) {
		newAddress.setAddressId(oldAddressId);
		return saveAddress(newAddress);
	}
	
	public List<Address> fetchAllAddress() {
		return addressRepo.findAll();
	}
}
