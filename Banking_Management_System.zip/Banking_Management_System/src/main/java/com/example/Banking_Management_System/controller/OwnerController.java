package com.example.Banking_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Banking_Management_System.dto.Owner;
import com.example.Banking_Management_System.service.OwnerService;
import com.example.Banking_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
public class OwnerController {

	@Autowired
	OwnerService ownerService;
	
	
	 @Operation(summary = "Save Owner", description = "API is used to save the Owner")
		@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created"),
				@ApiResponse(responseCode = "404", description = "Owner not found for the given id") })
	@PostMapping("/saveOwner")
	public ResponseEntity<ResponseStructure<Owner>> saveOwner(@RequestBody Owner owner) {
		return ownerService.saveOwner(owner);
	}

	 
	 @Operation(summary = "Fetch Owner", description = "API is used to Fetch the Owner")
		@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully fetched"),
				@ApiResponse(responseCode = "404", description = "Owner not found for the given id") })
	@GetMapping("/fetchOwnerById")
	public ResponseEntity<ResponseStructure<Owner>> fetchOwnerById(@RequestParam int ownerId) {
		return ownerService.fetchOwnerById(ownerId);
	}
	 
	 
	 @Operation(summary = "Delete Owner", description = "API is used to delete the Owner")
		@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully deleted"),
				@ApiResponse(responseCode = "404", description = "Owner not found for the given id") })
	@DeleteMapping("/deleteOwner")
	public ResponseEntity<ResponseStructure<Owner>> deleteOwner(@RequestParam int ownerId) {
		ResponseEntity<ResponseStructure<Owner>> owner = ownerService.fetchOwnerById(ownerId);
		ownerService.deleteOwner(ownerId);
		return owner;
	}

	 
	 @Operation(summary = "Update Owner", description = "API is used to update the Owner")
		@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully updated"),
				@ApiResponse(responseCode = "404", description = "Owner not found for the given id") })
	@PutMapping("/updateOwner")
	public ResponseEntity<ResponseStructure<Owner>> updateOwner(@RequestParam int oldOwnerId, @RequestBody Owner newOwner) {
		newOwner.setOwnerId(oldOwnerId);
		return saveOwner(newOwner);
	}

	@GetMapping("/fetchAllOwner")
	public List<Owner> fetchAllOwner() {
		return ownerService.fetchAllOwner();
	}

	@PutMapping("/addExistingBankToExistingOwner")
	public Owner addExistingBankToExistingOwner(@RequestParam int ownerId, @RequestParam int bankId) {
		return ownerService.addExistingBankToExistingOwner(ownerId, bankId);
	}
}
