package com.example.Banking_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Banking_Management_System.dao.AddressDao;
import com.example.Banking_Management_System.dto.Address;
import com.example.Banking_Management_System.exception.AddressIdNotFound;
import com.example.Banking_Management_System.util.ResponseStructure;


@Service
public class AddressService {
	@Autowired
	AddressDao addressDao;
	
	@Autowired
	ResponseStructure<Address> responseStructure;
	
	public ResponseEntity<ResponseStructure<Address>> saveAddress(Address address) {
		responseStructure.setMessage("Successfully address created in DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(addressDao.saveAddress(address));
		return new ResponseEntity<ResponseStructure<Address>>(responseStructure,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<Address>> fetchAddressById(int addressId) {
		Address address=addressDao.fetchAddressById(addressId);
		if(address!= null) {
		responseStructure.setMessage("Successfully address fetched from DB");
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setData(addressDao.fetchAddressById(addressId));
		return new ResponseEntity<ResponseStructure<Address>>(responseStructure,HttpStatus.FOUND);
		}else {
			throw new AddressIdNotFound();
		}
	}
	
	public ResponseEntity<ResponseStructure<Address>> deleteAddress(int addressId) {
		Address address=addressDao.fetchAddressById(addressId);
		if(address!= null) {
		responseStructure.setMessage("Successfully address deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(addressDao.deleteAddress(addressId));
	    return new ResponseEntity<ResponseStructure<Address>>(responseStructure,HttpStatus.OK);
		}else {
			throw new AddressIdNotFound();
		}
	}
	
	
	
	
	public  ResponseEntity<ResponseStructure<Address>> updateAddress(int oldAddressId, Address newAddress) {
		Address address=addressDao.fetchAddressById(oldAddressId);
		if(address!= null) {
		responseStructure.setMessage("Successfully address deleted from DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(addressDao.updateAddress(oldAddressId, newAddress));
		 return new ResponseEntity<ResponseStructure<Address>>(responseStructure,HttpStatus.OK);
	}else {
		throw new AddressIdNotFound();
	}
	}
	
	public List<Address> fetchAllAddress() {
		return addressDao.fetchAllAddress();
	}
}
