package com.example.Banking_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Banking_Management_System.dto.Manager;
import com.example.Banking_Management_System.service.ManagerService;
import com.example.Banking_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;


@RestController
public class ManagerController {
	@Autowired
	ManagerService managerService;
	
	
	
	@Operation(summary = "Save Manager", description = "API is used to save the Manager")
 	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully created"),
 			@ApiResponse(responseCode = "404", description = "Manager not found for the given id") })
	@PostMapping("/saveManager")
	public ResponseEntity<ResponseStructure<Manager>> saveManager(@RequestBody Manager manager) {
		return managerService.saveManager(manager);
	}
	
	
	
	@Operation(summary = "Fetch Manager", description = "API is used to fetch the Manager")
 	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully fetched"),
 			@ApiResponse(responseCode = "404", description = "Manager not found for the given id") })
	@GetMapping("/fetchManagerById")
	public ResponseEntity<ResponseStructure<Manager>> fetchmanagerById(@RequestParam int managerId) {
		return managerService.fetchManagerById(managerId);
	}
	
	
	
	@Operation(summary = "Delete Manager", description = "API is used to delete the Manager")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully deleted"),
			@ApiResponse(responseCode = "404", description = "Manager not found for the given id") })
	@DeleteMapping("/deleteManager")
	public ResponseEntity<ResponseStructure<Manager>> deleteManager(@RequestParam int managerId) {
		ResponseEntity<ResponseStructure<Manager>> manager=managerService.fetchManagerById(managerId);
	    managerService.deleteManager(managerId);
	    return manager;
	}
	
	

@Operation(summary = "Updated Manager", description = "API is used to update the Manager")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully updated"),
			@ApiResponse(responseCode = "404", description = "Manager not found for the given id") })
	@PutMapping("/updateManager")
	public ResponseEntity<ResponseStructure<Manager>> updateManager(@RequestParam int oldManagerId,@RequestBody Manager newManager) {
		newManager.setManagerId(oldManagerId);
		return saveManager(newManager);
	}
	
	@GetMapping("/fetchAllManager")
	public List<Manager> fetchAllManager() {
		return managerService.fetchAllManager();
	}

}
