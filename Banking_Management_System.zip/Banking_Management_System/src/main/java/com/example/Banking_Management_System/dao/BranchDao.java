package com.example.Banking_Management_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.example.Banking_Management_System.dto.Address;
import com.example.Banking_Management_System.dto.Branch;
import com.example.Banking_Management_System.dto.Customer;
import com.example.Banking_Management_System.dto.Employee;
import com.example.Banking_Management_System.dto.Manager;
import com.example.Banking_Management_System.repo.BranchRepo;

@Repository
public class BranchDao {

	@Autowired
	BranchRepo branchRepo;

	@Autowired
	ManagerDao managerDao;
	@Autowired
	AddressDao addressDao;

	@Autowired
	EmployeeDao employeeDao;
	@Autowired
	CustomerDao customerDao;

	public Branch saveBranch(Branch branch) {
		return branchRepo.save(branch);
	}

	public Branch fetchBranchById(int branchId) {
		Optional<Branch> branch= branchRepo.findById(branchId);
		if(branch.isEmpty()) {
			return null;
		}else {
			return branch.get();
		}
	}

	public Branch deleteBranch(int branchId) {
		Branch branch = branchRepo.findById(branchId).get();
		branchRepo.delete(branch);
		return branch;
	}

	public Branch updateBranch(int oldBranchId, Branch newBranch) {
		newBranch.setBranchId(oldBranchId);
		return saveBranch(newBranch);
	}

	public List<Branch> fetchAllBranch() {
		return branchRepo.findAll();
	}

	// One to One
	public Branch addExistingManagerToExistingBranch(int branchId, int managerId) {
		Branch branch = fetchBranchById(branchId);
		Manager manager = managerDao.fetchManagerById(managerId);
		branch.setManager(manager);
		return saveBranch(branch);
	}

	// One to One
	public Branch addExistingAddressToExistingBranch(int branchId, int addressId) {
		Branch branch = fetchBranchById(branchId);
		Address address = addressDao.fetchAddressById(addressId);
		branch.setAddress(address);
		return saveBranch(branch);
	}

	// one to many-- employee
	public Branch addExistingEmployeeToExistingbranch(int branchId, int employeeId) {
		Employee employee = employeeDao.fetchEmployeeById(employeeId);
		Branch branch = fetchBranchById(branchId);
		List<Employee> list = branch.getEmployees();
		list.add(employee);
		branch.setEmployees(list);
		return saveBranch(branch);
	}

	public Branch addnewEmployeeToExistingBranch(int branchId, Employee newEmployee) {
		Branch branch = fetchBranchById(branchId);
		List<Employee> list = branch.getEmployees();
		list.add(newEmployee);
		branch.setEmployees(list);
		return saveBranch(branch);
	}
	
	
	// one to many-- Customer
			public Branch addExistingCustomerToExistingBranch(int branchId, int customerId) {
				Customer customer = customerDao.fetchCustomerById(customerId);
				Branch branch = fetchBranchById(branchId);
				List<Customer> list = branch.getCustomers();
				list.add(customer);
				branch.setCustomers(list);
				return saveBranch(branch);
			}

			public Branch addNewCustomerToExistingBranch(int branchId, Customer newCustomer) {
				Branch branch = fetchBranchById(branchId);
				List<Customer> list = branch.getCustomers();
				list.add(newCustomer);
				branch.setCustomers(list);
				return saveBranch(branch);
			} 

}
